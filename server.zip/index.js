const mongoose=require('mongoose');
const express=require('express');
const router=express.Router();
const app=express();
const cookieParser = require("cookie-parser");
mongoose.connect(" mongodb://127.0.0.1:27017/matrimonial").then(()=>console.log("connection established")).catch((err)=>console.log(err));
app.use(express.json());

app.use(cookieParser());
app.use('/public',express.static("public"));
app.use(require('./routes/auth'));

app.get('/',(req,res)=>{
    res.send("Home page");
});
app.get('/login',(req,res)=>{
    res.send("Login page");
});
app.post('/register',(req,res)=>{
    const {name,email,phone,password,gender,dob}=req.body;

    res.send("Signup page");
});
app.get('/home',(req,res)=>{
    res.send("Welcome User page");
});
app.listen(5000,"localhost",()=>{console.log("Server started")});
